document.addEventListener("DOMContentLoaded", () => {
  const formConsulta = document.getElementById("formConsulta");
  const contatoTipoSelect = document.getElementById("contatoConsultaTipo");
  const contatoInput = document.getElementById("contatoConsulta");
  const resultadosDiv = document.getElementById("resultados");

  contatoTipoSelect.addEventListener("change", () => {
    if (contatoTipoSelect.value === "email") {
      contatoInput.type = "email";
      contatoInput.placeholder = "exemplo@dominio.com";
      contatoInput.value = "";
    } else if (contatoTipoSelect.value === "telefone") {
      contatoInput.type = "tel";
      contatoInput.placeholder = "(99) 99999-9999";
      contatoInput.value = "";
    } else {
      contatoInput.type = "text";
      contatoInput.placeholder = "Selecione o tipo de contato";
      contatoInput.value = "";
    }
  });

  formConsulta.addEventListener("submit", (e) => {
    e.preventDefault();

    if (!formConsulta.checkValidity()) {
      formConsulta.reportValidity();
      return;
    }

    const contatoTipo = contatoTipoSelect.value;
    const contato = contatoInput.value.trim();

    fetch(
      `http://localhost:3000/api/solicitacoes?contatoTipo=${encodeURIComponent(
        contatoTipo
      )}&contato=${encodeURIComponent(contato)}`
    )
      .then((res) => {
        if (!res.ok) throw new Error("Erro ao consultar");
        return res.json();
      })
      .then((dados) => {
        resultadosDiv.innerHTML = "";
        if (dados.length === 0) {
          resultadosDiv.innerHTML = "<p>Nenhuma solicitação encontrada.</p>";
          return;
        }

        dados.forEach((item) => {
          if (item.anonimo) return; // Ignorar denúncias anônimas no resultado
          const div = document.createElement("div");
          div.classList.add("result-item");
          div.innerHTML = `
            <p><strong>ID:</strong> ${item.id}</p>
            <p><strong>Tipo:</strong> ${item.tipo}</p>
            <p><strong>Nome:</strong> ${item.nome}</p>
            <p><strong>Mensagem:</strong> ${item.mensagem}</p>
            <p><strong>Status:</strong> ${item.status}</p>
            <p><strong>Resposta:</strong> ${item.resposta || "Nenhuma"}</p>
            <hr />
          `;
          resultadosDiv.appendChild(div);
        });
      })
      .catch(() => {
        resultadosDiv.innerHTML = "<p>Erro ao consultar solicitações.</p>";
      });
  });
});
