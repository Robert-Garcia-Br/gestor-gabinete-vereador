// routes/solicitacoes.js
const express = require("express");
const fs = require("fs");
const path = require("path");

const router = express.Router();

const DB_PATH = path.join(__dirname, "..", "data", "db.json");

// Função para carregar dados do arquivo JSON
function carregarDados() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, "[]");
  }
  const conteudo = fs.readFileSync(DB_PATH, "utf-8").trim();

  if (!conteudo) {
    fs.writeFileSync(DB_PATH, "[]");
    return [];
  }

  try {
    const dados = JSON.parse(conteudo);
    // Se não for array, retornar array vazio
    if (!Array.isArray(dados)) {
      return [];
    }
    return dados;
  } catch (err) {
    // Se der erro no parse, reseta o arquivo e retorna array vazio
    fs.writeFileSync(DB_PATH, "[]");
    return [];
  }
}

// Função para salvar dados no arquivo JSON
function salvarDados(dados) {
  fs.writeFileSync(DB_PATH, JSON.stringify(dados, null, 2));
}

// POST /api/solicitacoes - cria nova solicitação
router.post("/", (req, res) => {
  try {
    const dados = carregarDados();

    const { tipo, anonimo, nome, contato, mensagem } = req.body;
    if (!tipo || !mensagem) {
      return res.status(400).json({ erro: "Tipo e mensagem são obrigatórios." });
    }
    if (!anonimo && (!nome || !contato)) {
      return res.status(400).json({ erro: "Nome e contato são obrigatórios se não for anônimo." });
    }

    const novaSolicitacao = {
      id: Date.now(),
      tipo,
      anonimo: !!anonimo,
      nome: anonimo ? "Anônimo" : nome,
      contato: anonimo ? "" : contato,
      mensagem,
      status: "Pendente",
      resposta: "", // Garante o campo resposta
      data: new Date().toISOString(),
    };

    dados.push(novaSolicitacao);
    salvarDados(dados);

    res.status(201).json(novaSolicitacao);
  } catch (err) {
    console.error("Erro no POST /api/solicitacoes:", err);
    res.status(500).json({ erro: "Erro ao criar solicitação." });
  }
});

// GET /api/solicitacoes?contato=xxxx - busca solicitações pelo contato
router.get("/", (req, res) => {
  try {
    const contato = req.query.contato;
    if (!contato) {
      return res.status(400).json({ erro: "Contato é obrigatório." });
    }

    const dados = carregarDados();
    const resultados = dados.filter((r) => r.contato === contato);
    res.json(resultados);
  } catch (err) {
    console.error("Erro no GET /api/solicitacoes:", err);
    res.status(500).json({ erro: "Erro ao carregar solicitações." });
  }
});

module.exports = router;
