const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const solicitacoesRouter = require("./routes/solicitacoes");
const adminRouter = require("./admin/admin");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());

// Rotas do frontend (API)
app.use("/api/solicitacoes", solicitacoesRouter);

// Rotas do admin (API)
app.use("/admin/api/solicitacoes", adminRouter);

app.listen(PORT, () => {
  console.log(`Servidor backend rodando em http://localhost:${PORT}`);
});
