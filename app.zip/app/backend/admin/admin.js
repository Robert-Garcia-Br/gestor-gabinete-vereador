const express = require("express");
const router = express.Router();
const fs = require("fs");
const path = require("path");

const dbPath = path.join(__dirname, "../data/db.json");

function lerDB() {
  const data = fs.readFileSync(dbPath, "utf-8");
  return JSON.parse(data);
}

router.get("/", (req, res) => {
  const db = lerDB();
  res.json(db); // Retorna o array diretamente
});

router.put("/:id", (req, res) => {
  const id = Number(req.params.id);
  const { status, resposta } = req.body;
  let db = lerDB();
  const idx = db.findIndex((item) => item.id === id);
  if (idx === -1) return res.status(404).json({ erro: "Solicitação não encontrada" });

  db[idx].status = status;
  db[idx].resposta = resposta;

  fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
  res.json(db[idx]);
});

module.exports = router;
